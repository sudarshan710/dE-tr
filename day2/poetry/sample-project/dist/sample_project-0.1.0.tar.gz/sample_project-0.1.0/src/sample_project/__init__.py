def greet(name:str):
    print(f"Hello {name}")